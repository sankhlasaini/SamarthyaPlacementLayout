import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-post',
  templateUrl: './event-post.component.html',
  styleUrls: ['./event-post.component.css']
})
export class EventPostComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
