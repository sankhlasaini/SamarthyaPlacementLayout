import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { ValidationService } from '../../services/validation.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {

  public languages = [
    { name: 'English' },
    { name: 'Hindi' },
  ];
  public userForm: FormGroup;

  constructor( @Inject(FormBuilder) fb: FormBuilder) {
    this.userForm = fb.group({
      email: ['', [Validators.required, ValidationService.emailValidator]],
      password: ['', [Validators.required, ValidationService.passwordValidator]]
    });
  }
  onSubmit() {
    console.log(this.userForm.value);
  }




}
