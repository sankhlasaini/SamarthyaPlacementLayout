import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-search',
  templateUrl: './candidate-search.component.html',
  styleUrls: ['./candidate-search.component.css']
})
export class CandidateSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
