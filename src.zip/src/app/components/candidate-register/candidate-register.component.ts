import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidate-register',
  templateUrl: './candidate-register.component.html',
  styleUrls: ['./candidate-register.component.css']
})
export class CandidateRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
